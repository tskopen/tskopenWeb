<?php
/**
 * Wildcard Helper Classes - Plugin Installer
 * interface
 */

interface WildcardPluginInstallerInterface010000
{
	public function install();
	public function uninstall();
}

?>
