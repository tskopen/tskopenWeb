<?php

/*
 * this file is simply here to overwrite the old plug-in file (if it still exists) and prevent two instances of ASB from showing up in ACP
 */

?>
