<?php
/*
 * Plugin Name: Advanced Sidebox for MyBB 1.8.x
 * Copyright 2014 WildcardSearch
 * http://www.rantcentralforums.com
 *
 * contains language used on the forum side
 */

$l['asb'] = 'Advanced Sidebox';

 // UCP
$l['asb_show_sidebox'] = 'Show side boxes.';

// visibility toggle icons
$l['asb_toggle_show'] = 'show side boxes';
$l['asb_toggle_hide'] = 'hide side boxes';

?>
